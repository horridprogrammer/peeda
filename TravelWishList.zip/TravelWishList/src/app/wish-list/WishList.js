import React, { useState, useEffect } from 'react';
import '../../App.css';

const WishList = ({ initialLocations }) => {
  const [locations, setLocations] = useState(initialLocations);
  const [newLocation, setNewLocation] = useState('');
  const [error, setError] = useState('');



  const addLocation = (newLocation) => {
    // check if location is not empty and does not exists alread
    // add new location to whish list and clear erros 

  };

  const removeLocation = (locationToRemove) => {
    // remove locations locations
  };

  const handleSubmit = (e) => {
    // prevent default submistion and call add location form
    // clear new location state
    
  };

  return (
    <div className="wish-list-container">

      <h2>Travel Wish List</h2>
      <ul className="location-list">
      {/* list down locations using map  */}
        
      </ul>
      {/* display locations erros  */}
     {/* create location form and call addLocation method on submission */}
    </div>
  );
};

export default WishList;
