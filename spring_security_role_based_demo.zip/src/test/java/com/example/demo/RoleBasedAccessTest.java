
package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Base64;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class RoleBasedAccessTest {

    @Autowired
    private MockMvc mockMvc;

    private String basicAuth(String username, String password) {
        return "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes());
    }

    @Test
    void userDashboardAccessibleByUserRole() throws Exception {
        // TODO: Expect 200 OK for user with USER role
        mockMvc.perform(get("/user/dashboard")
                .header(HttpHeaders.AUTHORIZATION, basicAuth("user", "pass123")))
                .andExpect(status().isOk());
    }

    @Test
    void adminPanelAccessibleByAdminRole() throws Exception {
        // TODO: Expect 200 OK for user with ADMIN role
        mockMvc.perform(get("/admin/panel")
                .header(HttpHeaders.AUTHORIZATION, basicAuth("admin", "admin123")))
                .andExpect(status().isOk());
    }

    @Test
    void userCannotAccessAdminPanel() throws Exception {
        // TODO: Expect 403 Forbidden for USER role trying to access /admin/panel
        mockMvc.perform(get("/admin/panel")
                .header(HttpHeaders.AUTHORIZATION, basicAuth("user", "pass123")))
                .andExpect(status().isForbidden());
    }
}
