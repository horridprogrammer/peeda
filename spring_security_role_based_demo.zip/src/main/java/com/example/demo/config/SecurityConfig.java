
package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // TODO: Secure /user/** to USER role, /admin/** to ADMIN role
        // TODO: Use httpBasic() for authentication
        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {
        // TODO: Define users with roles USER and ADMIN
        return null;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // TODO: Return a BCryptPasswordEncoder
        return null;
    }
}
