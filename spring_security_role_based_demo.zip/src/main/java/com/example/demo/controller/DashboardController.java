
package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DashboardController {

    @GetMapping("/user/dashboard")
    public String userDashboard() {
        // TODO: Return "User Dashboard"
        return "";
    }

    @GetMapping("/admin/panel")
    public String adminPanel() {
        // TODO: Return "Admin Panel"
        return "";
    }
}
