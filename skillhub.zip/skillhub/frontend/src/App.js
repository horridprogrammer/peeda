import './App.css';
import AddUser from './component/user/AddUser';

function App() {
  return (
    <div className="App">
      <AddUser/>
    </div>
  );
}

export default App;
