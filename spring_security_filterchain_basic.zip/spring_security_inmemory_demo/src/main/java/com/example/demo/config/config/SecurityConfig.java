
package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // TODO: Configure security to allow /public without authentication and secure all other endpoints
        // TODO: Use httpBasic() for authentication
        return http.build(); // replace after configuration
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {
        // TODO: Create two in-memory users: 'user' (role USER) and 'admin' (role ADMIN)
        // Use encoder.encode("password") to encode passwords
        return null; // replace with new InMemoryUserDetailsManager(...)
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // TODO: Return a BCryptPasswordEncoder
        return null;
    }
}
