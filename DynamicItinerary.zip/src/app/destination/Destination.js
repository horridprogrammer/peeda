// Destination.js
import React, { useEffect } from 'react';

const Destination = ({ id, name, location, onRemove }) => {
  // Simulate data fetching on initialization
  
    
    // Cleanup function to log when component unmounts
    
  

  const handleRemove = () => {
    // call OnRemove of Parent
  };

  return (
    <div className="destination-container">
     {/* display desitnation and remove button */}
    </div>
  );
};

export default Destination;
